# Titan Tapper Android APK Wrapper

Это Android-версия игры Titan Tapper в формате проекта для сборки APK.

Важно: это не заменяет сервер игры. APK открывает твою веб-игру через WebView. Сервер FastAPI и бот должны быть запущены отдельно на HTTPS-хостинге, например Render/Railway/VPS/ngrok.

## Что внутри

- Нативное Android-приложение на Java.
- WebView для открытия игры.
- Поддержка JavaScript и localStorage.
- Проверка интернета.
- Экран ошибки, если ссылка не указана.
- GitHub Actions workflow для сборки APK без компьютера.

## Как указать ссылку на игру

Открой файл:

```text
app/build.gradle
```

Найди строку:

```gradle
buildConfigField 'String', 'GAME_URL', '"https://YOUR-GAME-DOMAIN-HERE.com"'
```

Замени на свою HTTPS-ссылку:

```gradle
buildConfigField 'String', 'GAME_URL', '"https://titan-tapper.onrender.com"'
```

Не используй `localhost`, потому что APK на телефоне не увидит сервер на твоём ПК.

## Как собрать APK через Android Studio

1. Установи Android Studio.
2. Открой папку `titan_tapper_android`.
3. Дождись синхронизации Gradle.
4. Вставь свою ссылку в `GAME_URL`.
5. Нажми `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.
6. APK появится в:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Как собрать APK с телефона через GitHub Actions

1. Создай новый репозиторий на GitHub.
2. Загрузи туда все файлы из папки `titan_tapper_android`.
3. Открой файл `app/build.gradle` прямо на GitHub.
4. Замени `GAME_URL` на свою HTTPS-ссылку.
5. Перейди во вкладку `Actions`.
6. Запусти workflow `Build Titan Tapper APK`.
7. После сборки скачай artifact `titan-tapper-debug-apk`.
8. Внутри будет `app-debug.apk`.

## Как установить APK на Android

1. Скачай `app-debug.apk` на телефон.
2. Открой файл.
3. Разреши установку из неизвестных источников.
4. Установи приложение.

## Для публикации в Google Play

Debug APK не подходит для публикации в Google Play. Для Play Market нужен release build, подпись ключом, privacy policy и production-настройки. Этот проект можно доработать под release-сборку.
