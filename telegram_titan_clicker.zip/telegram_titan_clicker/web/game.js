const tg = window.Telegram?.WebApp;

const defaultState = {
  level: 1,
  stage: 1,
  gold: 0,
  damage: 1,
  critLevel: 0,
  autoLevel: 0,
  hp: 40,
  maxHp: 40,
  sound: true,
};

let state = loadState();
let lastAutoTick = Date.now();

const bosses = [
  { name: 'Лесной Титан', emoji: '🗿' },
  { name: 'Огненный Голем', emoji: '🔥' },
  { name: 'Ледяной Колосс', emoji: '🧊' },
  { name: 'Теневой Рыцарь', emoji: '💀' },
  { name: 'Золотой Дракон', emoji: '🐉' },
];

const $ = (id) => document.getElementById(id);

const ui = {
  level: $('level'),
  stage: $('stage'),
  gold: $('gold'),
  damage: $('damage'),
  hp: $('hp'),
  maxHp: $('maxHp'),
  hpBar: $('hpBar'),
  bossName: $('bossName'),
  bossEmoji: $('bossEmoji'),
  bossBtn: $('bossBtn'),
  hitFx: $('hitFx'),
  damageCost: $('damageCost'),
  critCost: $('critCost'),
  autoCost: $('autoCost'),
  upgradeDamage: $('upgradeDamage'),
  upgradeCrit: $('upgradeCrit'),
  upgradeAuto: $('upgradeAuto'),
  saveBtn: $('saveBtn'),
  resetBtn: $('resetBtn'),
  soundBtn: $('soundBtn'),
};

initTelegram();
render();
setInterval(autoAttack, 1000);
setInterval(saveState, 4000);

ui.bossBtn.addEventListener('click', () => attack(false));
ui.upgradeDamage.addEventListener('click', buyDamage);
ui.upgradeCrit.addEventListener('click', buyCrit);
ui.upgradeAuto.addEventListener('click', buyAuto);
ui.saveBtn.addEventListener('click', () => {
  saveState();
  toast('Прогресс сохранён');
  haptic('success');
});
ui.resetBtn.addEventListener('click', resetGame);
ui.soundBtn.addEventListener('click', () => {
  state.sound = !state.sound;
  ui.soundBtn.textContent = state.sound ? '🔊' : '🔇';
  saveState();
});

function initTelegram() {
  if (!tg) return;
  tg.ready();
  tg.expand();

  const params = tg.themeParams || {};
  if (params.bg_color) document.documentElement.style.setProperty('--bg', params.bg_color);
  if (params.text_color) document.documentElement.style.setProperty('--text', params.text_color);
  if (params.hint_color) document.documentElement.style.setProperty('--muted', params.hint_color);
  if (params.button_color) document.documentElement.style.setProperty('--accent', params.button_color);

  tg.MainButton.setText('СОХРАНИТЬ ПРОГРЕСС');
  tg.MainButton.onClick(() => {
    saveState();
    toast('Сохранено в браузере Telegram');
    haptic('success');
  });
  tg.MainButton.show();
}

function attack(isAuto) {
  let hit = state.damage + state.autoLevel;
  const critChance = Math.min(0.05 + state.critLevel * 0.035, 0.45);
  const crit = Math.random() < critChance;
  if (crit) hit *= 3;

  state.hp = Math.max(0, state.hp - hit);
  showHit(hit, crit, isAuto);
  haptic(crit ? 'heavy' : 'light');
  playClick();

  if (state.hp <= 0) defeatBoss();
  render();
}

function defeatBoss() {
  const reward = Math.round(12 + state.level * 5 + state.stage * 3);
  state.gold += reward;
  state.level += 1;
  state.stage += 1;
  state.maxHp = Math.round(38 + state.level * 14 + Math.pow(state.level, 1.22) * 7);
  state.hp = state.maxHp;
  toast(`Босс побеждён! +${reward} золота`);
  haptic('success');
}

function buyDamage() {
  const cost = damageCost();
  if (state.gold < cost) return toast('Не хватает золота');
  state.gold -= cost;
  state.damage += 1;
  render();
  saveState();
}

function buyCrit() {
  const cost = critCost();
  if (state.gold < cost) return toast('Не хватает золота');
  state.gold -= cost;
  state.critLevel += 1;
  render();
  saveState();
}

function buyAuto() {
  const cost = autoCost();
  if (state.gold < cost) return toast('Не хватает золота');
  state.gold -= cost;
  state.autoLevel += 1;
  render();
  saveState();
}

function autoAttack() {
  if (state.autoLevel <= 0) return;
  const now = Date.now();
  if (now - lastAutoTick < 900) return;
  lastAutoTick = now;
  attack(true);
}

function render() {
  const boss = bosses[(state.stage - 1) % bosses.length];
  const hpPercent = Math.max(0, (state.hp / state.maxHp) * 100);

  ui.level.textContent = state.level;
  ui.stage.textContent = state.stage;
  ui.gold.textContent = Math.floor(state.gold);
  ui.damage.textContent = state.damage + state.autoLevel;
  ui.hp.textContent = Math.ceil(state.hp);
  ui.maxHp.textContent = state.maxHp;
  ui.hpBar.style.width = `${hpPercent}%`;
  ui.bossName.textContent = boss.name;
  ui.bossEmoji.textContent = boss.emoji;
  ui.damageCost.textContent = damageCost();
  ui.critCost.textContent = critCost();
  ui.autoCost.textContent = autoCost();
  ui.soundBtn.textContent = state.sound ? '🔊' : '🔇';

  ui.upgradeDamage.disabled = state.gold < damageCost();
  ui.upgradeCrit.disabled = state.gold < critCost();
  ui.upgradeAuto.disabled = state.gold < autoCost();
}

function showHit(amount, crit, isAuto) {
  ui.hitFx.textContent = `${isAuto ? '⚔️ ' : ''}-${amount}${crit ? ' CRIT' : ''}`;
  ui.hitFx.classList.remove('show');
  ui.bossBtn.classList.remove('hit');
  void ui.hitFx.offsetWidth;
  ui.hitFx.classList.add('show');
  ui.bossBtn.classList.add('hit');
  setTimeout(() => ui.bossBtn.classList.remove('hit'), 110);
}

function damageCost() {
  return Math.round(15 * Math.pow(1.48, state.damage - 1));
}

function critCost() {
  return Math.round(40 * Math.pow(1.72, state.critLevel));
}

function autoCost() {
  return Math.round(75 * Math.pow(1.9, state.autoLevel));
}

function loadState() {
  try {
    const saved = JSON.parse(localStorage.getItem('titan-tapper-save'));
    return { ...defaultState, ...saved };
  } catch {
    return { ...defaultState };
  }
}

function saveState() {
  localStorage.setItem('titan-tapper-save', JSON.stringify(state));
}

function resetGame() {
  const ok = confirm('Сбросить весь прогресс?');
  if (!ok) return;
  state = { ...defaultState };
  saveState();
  render();
  toast('Прогресс сброшен');
}

function toast(message) {
  let el = document.querySelector('.toast');
  if (!el) {
    el = document.createElement('div');
    el.className = 'toast';
    document.body.appendChild(el);
  }
  el.textContent = message;
  el.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => el.classList.remove('show'), 1700);
}

function haptic(type) {
  if (!tg?.HapticFeedback) return;
  if (type === 'success') return tg.HapticFeedback.notificationOccurred('success');
  if (type === 'heavy') return tg.HapticFeedback.impactOccurred('heavy');
  tg.HapticFeedback.impactOccurred('light');
}

function playClick() {
  if (!state.sound) return;
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    const ctx = playClick.ctx || new AudioContext();
    playClick.ctx = ctx;
    const oscillator = ctx.createOscillator();
    const gain = ctx.createGain();
    oscillator.connect(gain);
    gain.connect(ctx.destination);
    oscillator.frequency.value = 340;
    gain.gain.setValueAtTime(0.025, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.04);
    oscillator.start();
    oscillator.stop(ctx.currentTime + 0.045);
  } catch {}
}
