# Titan Tapper — Telegram Mini App игра

Мини-игра в стиле Tap Titans: игрок тапает по боссу, получает золото, прокачивает урон, крит и авто-удары.

## Что внутри

- `web/` — сама игра: HTML, CSS, JavaScript.
- `bot/` — простой Telegram-бот на Node.js + grammY, который открывает игру через кнопку Web App.

## Быстрый запуск игры локально

Открой `web/index.html` в браузере. В Telegram некоторые функции, например haptic feedback и MainButton, работают только внутри Mini App.

## Как запустить в Telegram

1. Создай бота в Telegram через `@BotFather` и получи `BOT_TOKEN`.
2. Залей папку `web/` на HTTPS-хостинг. Подойдут Vercel, Netlify, GitHub Pages или свой VPS с SSL.
3. В BotFather привяжи домен/URL мини-приложения к боту, если используешь меню Mini App.
4. Перейди в папку `bot/`:

```bash
npm install
cp .env.example .env
```

5. В `.env` укажи:

```bash
BOT_TOKEN=твой_токен_бота
WEBAPP_URL=https://твой-домен.com
```

6. Запусти бота:

```bash
npm start
```

7. В Telegram напиши своему боту `/start` и нажми кнопку игры.

## Что можно улучшить дальше

- Добавить серверную базу данных и авторизацию через `Telegram.WebApp.initData`.
- Добавить таблицу лидеров.
- Добавить ежедневные награды.
- Добавить скины, новые миры и задания.
- Добавить монетизацию через Telegram Payments/Stars.

## Важно

Сейчас прогресс сохраняется в `localStorage` на устройстве пользователя. Для реального релиза лучше хранить прогресс на сервере и проверять `initData`, чтобы игроки не могли накрутить золото через DevTools.
