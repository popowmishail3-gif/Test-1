import 'dotenv/config';
import { Bot, InlineKeyboard } from 'grammy';

const token = process.env.BOT_TOKEN;
const webAppUrl = process.env.WEBAPP_URL;

if (!token) throw new Error('Добавь BOT_TOKEN в .env');
if (!webAppUrl) throw new Error('Добавь WEBAPP_URL в .env');

const bot = new Bot(token);

bot.command('start', async (ctx) => {
  const keyboard = new InlineKeyboard().webApp('🎮 Играть в Titan Tapper', webAppUrl);
  await ctx.reply(
    'Готово! Нажми кнопку ниже, чтобы открыть мини-игру прямо в Telegram.',
    { reply_markup: keyboard }
  );
});

bot.command('help', async (ctx) => {
  await ctx.reply('Команды: /start — открыть игру. Прогресс сохраняется в Telegram-браузере через localStorage.');
});

bot.catch((err) => {
  console.error('Bot error:', err);
});

bot.start();
console.log('Titan Tapper bot started');
